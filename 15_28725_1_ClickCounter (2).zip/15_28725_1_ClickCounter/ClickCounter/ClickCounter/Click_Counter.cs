﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ClickCounter
{
    public partial class Form1 : Form
    {
        Random r1 = new Random();
        int score;
        public Form1()
        {


            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            if (b.BackColor == Color.Green)
            {
                score = score + 5;

            }
            else if (b.BackColor == Color.Red)
            {
                score = score - 5;

            }
            else { }
            label2.Text = "Score:" + score;


        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            int x = r1.Next(10);
            label1.Text = "number is+" + x;
            switch (x)
            {

                case 1:
                    button1.BackColor = Color.Green;
                    break;
                case 2:
                    button2.BackColor = Color.Green;
                    break;

                case 3:
                    button3.BackColor = Color.Green;
                    break;

                case 4:
                    button4.BackColor = Color.Green;
                    break;
                case 5:
                    button5.BackColor = Color.Green;
                    break;
                case 6:
                    button6.BackColor = Color.Green;
                    break;

                case 7:
                    button7.BackColor = Color.Green;
                    break;
                case 8:
                    button8.BackColor = Color.Green;
                    break;
                case 9:
                    button9.BackColor = Color.Green;
                    break;
                case 10:
                    button10.BackColor = Color.Green;
                    break;
                default:
                    break;

            }

        }
        public void Color_Reset()
        {

            foreach (Control c in this.Controls)
            {
                Button btn = c as Button;
                if (btn != null) // if c is another type, btn will be null
                {
                    if (btn.Text == "Start")
                    {

                    }
                    else if (btn.Text == "Pause") { }
                    else if (btn.Text == "Reset") { }
                    else
                    {



                        btn.BackColor = Color.Red;



                    }
                }
            }


        }

        private void button11_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            timer1.Start();
            timer2.Start();
            foreach (Control c in this.Controls)
            {
                Button btn = c as Button;
                if (btn != null) // if c is another type, btn will be null
                {
                    if (btn.Text == "Start")
                    {

                    }
                    else if (btn.Text == "Pause") { }
                    else if (btn.Text == "Reset") { }
                    else
                    {



                        btn.Enabled = true;



                    }
                }
            }
        }
            

        private void timer2_Tick(object sender, EventArgs e)
        {
            Color_Reset();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            timer2.Stop();
            foreach (Control c in this.Controls)
            {
                Button btn = c as Button;
                if (btn != null) // if c is another type, btn will be null
                {
                    if (btn.Text == "Start")
                    {

                    }
                    else if (btn.Text == "Pause") { }
                    else if (btn.Text == "Reset") { }
                    else
                    {



                        btn.Enabled = false;



                    }
                }

            }
        }

            private void button13_Click(object sender, EventArgs e)
            {

                score = 0;
                timer1.Stop();
                timer2.Stop();
                label2.Text = "Score:" + score;
                Color_Reset();
            }
        }



    }


        
    

