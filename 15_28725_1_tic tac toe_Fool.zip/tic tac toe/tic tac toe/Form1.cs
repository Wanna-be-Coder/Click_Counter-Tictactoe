﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tic_tac_toe
{
    public partial class Form1 : Form
    {
        public Boolean turn = true;
        int count = 0;
        public Form1()
        {
            InitializeComponent();
        }

         private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void move_made(object sender, EventArgs e)
        {
           
            Button b = (Button)sender;
            if (turn)
            {
                b.Text = "X";
                turn = false;
                b.Enabled = false;
            }
            else
            {
                
                    b.Text = "O";
                    turn = true;
                    b.Enabled = false;
              
            }
            CheckWinner();
           
        }

        public void CheckWinner()
        {
            bool winner = false;
            if (A1.Text == A2.Text && A2.Text == A3.Text && A1.Enabled ==false)
            {

                winner = true;
                
            }
            else if (A1.Text == B1.Text && B1.Text == C1.Text && C1.Enabled==false)
            {
                winner = true;
                
            }
            else if (A2.Text == B2.Text && B2.Text == C2.Text && C2.Enabled == false)
            {
                winner = true;
            }
            else if (A3.Text == B3.Text && B3.Text == C3.Text && C3.Enabled == false)
            {
                winner = true;
            }
            else if (B1.Text == B2.Text && B2.Text == B3.Text && B2.Enabled ==false)
            {
                winner = true;
               

            }
            else if (C1.Text == C2.Text && C2.Text == C3.Text && C3.Enabled == false)
            {
                winner = true;
                
            }
            else if (A1.Text == B2.Text && B2.Text == C3.Text && C3.Enabled == false)
            {
                winner = true;
            }
            else if (A3.Text == B2.Text && B2.Text == C1.Text && C1.Enabled == false)
            {
                winner = true;
            }
            else { count++; }
            if (winner == true)
            {

                if (!turn)
                {
                    Form2 result = new Form2();
                    result.Visible = true;
                    result.Text = "X Wins";
                    this.Visible = false;
                }
                else {
                    Form2 result = new Form2();
                    result.Visible = true;
                    result.Text = "O Wins";
                    this.Visible = false;

                
                }

                
                

            }
            else if (count == 9)
            {
                Form2 result = new Form2();
                result.Visible = true;
                result.Text = "Its a Draw";
                this.Visible = false;
            }
            else { }
        }
       
           
        
        
        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
    

}
