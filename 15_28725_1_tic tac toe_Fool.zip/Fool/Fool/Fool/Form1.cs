﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fool
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            MessageBox.Show("You are still a fool -_-");
        }

        private void button1_MouseEnter(object sender, EventArgs e)
        {
            Random r = new Random();
            int x, y;
            x = r.Next(291-75) + 1;
            y = r.Next(300-29) + 1;
            button1.Location = new Point(x, y);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("You are a Fool");
        }
    }
}
